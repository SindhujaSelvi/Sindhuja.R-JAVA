class AcessSingleton
{
    public static void main(String Args[])
    {
        SingletonClass vanitha=SingletonClass.getInstance();
        vanitha.getSomeThing();

    }
}