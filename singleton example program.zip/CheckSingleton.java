class CheckSingleton
{
    public static void main(String args[])
    {
        SingletonClass s = SingletonClass.getInstance();
        s.getSomeThing();
    }
}