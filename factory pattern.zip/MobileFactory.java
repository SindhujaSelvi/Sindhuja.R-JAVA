
class MobileFactory {

    public static Mobile createMobile(String type) {
        if (type.equals(Mobile.SAMSUNG)) {
            return new Samsung("GALAXY J7", "Android", 1400);
        } else if (type.equals(Mobile.SONY)) {
            return new Sony("Xperia", "Android");
        } else if (type.equals(Mobile.IPHONE)) {
            return new Iphone("7 Plus");
        } else
            return null;
    }
}