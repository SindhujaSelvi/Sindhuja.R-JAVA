class Sony implements Mobile{

    String name;
    String os;
    public Sony(String name, String os)
    {
        this.name=name;
        this.os=os;

    }

    public String toString(){
        return "Name: "+name+",Os: "+os;
    }
}