interface Mobile
{
    public static final String SAMSUNG="Samsung";
    public static final String IPHONE="Iphone";
    public static final String SONY="Sony";
}