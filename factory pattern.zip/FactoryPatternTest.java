class FactoryPatternTest
{
    public static void main(String[] args) {
        Mobile m = MobileFactory.createMobile(Mobile.SAMSUNG);
        System.out.println(m);
    }
}