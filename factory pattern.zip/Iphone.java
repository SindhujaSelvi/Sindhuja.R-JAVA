class Iphone implements Mobile{

    String name;
    public Iphone(String name)
    {
        this.name=name;

    }

    public String toString(){
        return "Name: "+name;
    }
}